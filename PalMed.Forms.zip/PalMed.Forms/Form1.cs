﻿using PalMed.Forms.PalMedService;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalMed.Forms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btEjecutar_Click(object sender, EventArgs e)
        {
            List<Imagen> imagenes = new List<Imagen>();

            WebService1 ws = new WebService1();

            List<int> fotosIds = ws.GetFotosId().ToList();

            if (fotosIds.Count > 0)
            {
                int i = 0;
                while (i < fotosIds.Count)
                {
                    int j = 0;
                    List<int> aux = new List<int>();
                    while (i < fotosIds.Count && j < 10)
                    {
                        aux.Add(fotosIds[i]);
                        i++;
                        j++;
                    }

                    imagenes.AddRange(ws.GetFotosPaginado(aux.ToArray()).Cast<Imagen>().ToList());
                }
            }

            foreach (Imagen imagen in imagenes)
            {
                string path = @"C:\\Palmed\Imagenes\" + imagen.Ruta.Replace("/", "\\");
                string directory = Path.GetDirectoryName(path);

                bool exists = Directory.Exists(directory);

                if (exists)
                {
                    File.WriteAllBytes(path, imagen.Foto);
                }
                else
                {
                    Directory.CreateDirectory(directory);
                    File.WriteAllBytes(path, imagen.Foto);

                }

            }
        }
    }
}
